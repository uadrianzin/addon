<?php

return [
    'password' => 'Wachtwoord',
    'sent' => 'We hebben u een wachtwoord herstel link gestuurd!',
    'user' => 'We kunnen geen gebruiker vinden met dat e-mail adres.',
];
