{{-- Pterodactyl - Panel --}}
{{-- Copyright (c) 2015 - 2017 Dane Everitt <dane@daneeveritt.com> --}}

{{-- This software is licensed under the terms of the MIT license. --}}
{{-- https://opensource.org/licenses/MIT --}}
@extends('layouts.master')

@section('title')
    Subdomain Manager
@endsection

@section('content-header')
    <h1>Subdomain Manager
        <small>You can set Subdomain for your server.</small>
    </h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('index') }}">@lang('strings.home')</a></li>
        <li><a href="{{ route('server.index', $server->uuidShort) }}">{{ $server->name }}</a></li>
        <li>@lang('navigation.server.configuration')</li>
        <li class="active">Subdomain Manager</li>
    </ol>
@endsection

@section('content')
    <div class="row">
        @if (count($domains) > 0)
            <div class="col-xs-12 col-md-8">
                <div class="box box-success">
                    <div class="box-header with-border">
                        <h3 class="box-title mt-3">Create Subdomain</h3>
                    </div>
                    <form method="post" action="{{ route('server.subdomain.create', $server->uuidShort)  }}">
                        <div class="box-body">
                            <div class="row">
                                <div class="form-group col-md-6 col-xs-12">
                                    <label for="subdomain" class="form-label">Subdomain</label>
                                    <input type="text" id="subdomain" name="subdomain" class="form-control"
                                           placeholder="myserver">
                                </div>
                                <div class="form-group col-md-6 col-xs-12">
                                    <label for="domain" class="form-label">Domain</label>
                                    <select id="domain" name="domain" class="form-control">
                                        @foreach($domains as $domain)
                                            <option value="{{ $domain->id }}">.{{ $domain->domain }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            {!! csrf_field() !!}
                            <button type="submit" class="btn btn-success pull-right">Create</button>
                        </div>
                    </form>
                </div>

                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title mt-3">List Subdomain</h3>
                    </div>
                    <div class="box-body table-responsive no-padding">
                        <table class="table table-hover">
                            <tbody>
                            <tr>
                                <th>Subdomain</th>
                                <th>Server Allocation</th>
                                <th>Actions</th>
                            </tr>
                            @foreach ($subdomains as $subdomain)
                                <tr>
                                    <td><a href="javascript:;">{{ $subdomain->subdomain }}.{{ $subdomain->domain }}@if ($subdomain->record_type === 'CNAME'):{{ $subdomain->port }}@endif</a></td>
                                    <td><code>{{ $ip_alias }}:{{ $subdomain->port }}</code></td>
                                    <td>
                                        <a class="btn btn-xs btn-danger" data-action="delete" data-id="{{ $subdomain->id }}"><i class="fa fa-trash"></i></a>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="col-xs-12 col-md-4">
                <div class="box box-info">
                    <div class="box-header with-border">
                        <h3 class="box-title mt-3">Subdomain Help</h3>
                    </div>
                    <div class="box-body">
                        You can create Subdomain for your server. For example: <code>myserver.example.com</code> or
                        <code>myserver.example.com:25565</code>
                    </div>
                </div>
            </div>
        @else
            <div class="col-xs-12">
                <div class="alert alert-info alert-dismissable" role="alert">
                    No domain available for this server!
                </div>
            </div>
        @endif
    </div>
@endsection

@section('footer-scripts')
    @parent
    <script>
        $('[data-action="delete"]').click(function (event) {
            event.preventDefault();
            let self = $(this);
            swal({
                title: '',
                type: 'warning',
                text: 'Are you sure you want to delete this Subdomain?',
                showCancelButton: true,
                confirmButtonText: 'Delete',
                confirmButtonColor: '#d9534f',
                closeOnConfirm: false,
                showLoaderOnConfirm: true,
                cancelButtonText: 'Cancel',
            }, function () {
                $.ajax({
                    method: 'DELETE',
                    url: '/server/{{ $server->uuidShort }}/subdomain/delete',
                    headers: {'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')},
                    data: {
                        id: self.data('id')
                    }
                }).done((data) => {
                    if (data.success === true) {
                        swal({
                            type: 'success',
                            title: 'Success!',
                            text: 'You have successfully deleted this Subdomain.'
                        });

                        self.parent().parent().slideUp();
                    } else {
                        swal({
                            type: 'error',
                            title: 'Ooops!',
                            text: (typeof data.error !== 'undefined') ? data.error : 'Failed to delete this Subdomain! Please try again later...'
                        });
                    }
                }).fail((jqXhr) => {
                    console.log(jqXhr.responseText);
                    swal({
                        type: 'error',
                        title: 'Ooops!',
                        text: 'A system error has occurred! Please try again later...'
                    });
                });
            });
        });
    </script>
@endsection
